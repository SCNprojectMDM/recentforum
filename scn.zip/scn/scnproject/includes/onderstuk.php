<hr>
<footer class="container-fluid text-center">
          <div class="row">
            <div class="col-sm-4">
                <br>
                <a href="http://www.stichting-scn.nl/" target="blank">Designed at SCN</a>
                <br><br>
                <a href="https://discord.gg/GS5QTh" target="blank">Created By The &reg; Modding Group</a>
                <br><br>
                <a href="https://www.original-mike.com" target="blank">An Official Mike Incorporated Productions&trade;</a>
                <br><br>
            </div><div class="col-sm-4">
                <br>
                <a href="tools.php">SCN Project &rarr; Tools</a>
                <br><br>
                <a href="vehicles.php">SCN Project &rarr; Vehicles</a>
                <br><br>
                <a href="aircrafts.php">SCN Project &rarr; Aircrafts</a>
                <br><br>
                <a href="codes.php">SCN Project &rarr; Codes</a>
                <br><br>
                <a href="hacks.php">SCN Project &rarr; Hacks</a>
                <br><br>
                <a href="music.php">SCN Project &rarr; Music</a>
                <br><br>
                <a href="pictures.php">SCN Project &rarr; Pictures</a>
                <br><br>
                <a href="nsfw.php">SCN Project &rarr; NSFW</a>
                <br><br>
                <a href="team.php">SCN Project &rarr; The Team</p>
                <br><br>
            </div><div class="col-sm-4">
                <br>
            	<a href="contact.php">Contact</a>
                <br><br>
                <a href="privacypolicy.php">Privacy Policy</a>
                <br><br>
                <a href="termsofuse.php">Terms of Use</a>
                <br><br>
                <a href="log.php">Onze log</a>
            </div>
            
          </div>
        </footer>