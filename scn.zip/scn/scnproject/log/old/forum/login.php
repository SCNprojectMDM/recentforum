<!DOCTYPE HTML>
	<head>
		<meta charset="utf-8">
		<title>TheForm&reg;</title>
		<link rel="stylesheet" href="./css/styles.css">
	</head>
		<body>
			<header>
				<div class="container">
			        <div id="titel">
			          <a href="#"><h1><span class="highlight">The</span></span>Forum</h1></a>
			        </div>
			        <nav>
			          <ul>
			            <li><a href="#"><i class="home"></i>Inloggen</a></li>
			          </ul>
			        </nav>
			      </div>
			</header>

			<form action="signup.php" method="POST">
				 <input type="text" name="first" placeholder="First Name"><br>
				 <input type="text" name="last" placeholder="Last Name"><br>
				 <input type="text" name="uid" placeholder="Username"><br>
				 <input type="password" name="pwd" placeholder="Password"><br>
				 <button type="submit">Registreruh</button>
			</form>

		</body>
</head>