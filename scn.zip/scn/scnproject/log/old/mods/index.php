
<!DOCTYPE HTML>
	<head>
		<meta charset="utf-8">
		<title>Modded</title>
		<link rel="stylesheet" href="./css/styles.css">
	</head>
		<body>
			<header>
				<div class="container">
			        <div id="branding">
		        	<div class="logo"></div>
		        </div>
			        <nav>
			          <ul>
			            <li><a href="upload.php">Uploaden</a></li>
			            <li><a href="login.php">Inloggen</a></li>
			            <li><a href="registreren.php">Registreren</a></li>
			          </ul>
			        </nav>
			      </div>
			</header>
		</body>
</head>